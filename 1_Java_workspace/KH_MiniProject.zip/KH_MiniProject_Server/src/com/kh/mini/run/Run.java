package com.kh.mini.run;

import com.kh.mini.view.Information;

public class Run {

	public static void main(String[] args) {
		new Information();
	}

}
